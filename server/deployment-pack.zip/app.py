from flask import Flask, jsonify, request
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import User
from __init__ import db, app
from flask_cors import CORS
from flask_socketio import SocketIO, join_room, leave_room, send
import random 

CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*")


@app.route('/')
def index():
    return jsonify(message="Hello from Flask!")

@app.route('/signin', methods=['POST'])
def signin():
    data = request.get_json()

    # Check if username or email already exists
    existing_user = User.query.filter_by(username=data['username']).first()
    if existing_user:
        if existing_user.check_password(data['password']):
            return jsonify(message="User already exists. Logged in successfully."), 200
        else:
            return jsonify(message="Incorrect password."), 400

    user = User(username=data['username'])
    user.set_password(data['password'])
    db.session.add(user)
    db.session.commit()

    return jsonify(message="User created successfully."), 201


connected_players = {}

@socketio.on('connect')
def handle_connect():
    player_id = request.sid
    connected_players[player_id] = {
        "player_id": player_id,
        "game_room": None  # Will store the game room ID when the player joins a game
    }

@socketio.on('join_game_room')
def join_game_room(data):
    room = data['room_id']
    join_room(room)
    send(f"{request.sid} has entered the room.", room=room)

@socketio.on('send_chat_message')
def handle_chat_message(data):
    room = data['room_id']
    message = data['message']
    send(message, room=room)

@socketio.on('leave_game_room')
def leave_game_room(data):
    room = data['room_id']
    leave_room(room)
    send(f"{request.sid} has left the room.", room=room)

@socketio.on('send_message')
def handle_send_message(msg):
    print(f"Received {msg} event from React")
    socketio.emit('message_response', msg)


GRID = [[1, 2, 1, 2, 1],
        [2, 0, 2, 0, 2],
        [1, 2, 1, 2, 1],
        [2, 0, 2, 0, 2],
        [1, 2, 1, 2, 1]]


class GameGrid:

    def __init__(self):
        self.grid = GRID    
        self.players = []
        self.width = len(GRID[0])
        self.height = len(GRID)
        self.live = False
        self.answer = {}
        self.winner = None
        self.current_player = None

    @property
    def game_status(self):
        return {'status': self.live,
                'players': self.players,
                'winner': self.winner,
                'cur_player': self.current_player}

    def add_player(self) -> int:
        if not self.live:
            if len(self.players) < 6:
                while(True):
                    x, y = random.randint(0, 4), random.randint(0, 4)
                    if [x, y] not in self.players and self.grid[x][y] != 0:
                        break

                self.players.append([x, y])
                return len(self.players) - 1
        return -1

    def move_player(self, player_id: int, x: int, y: int):
        if not self.live:
            self.start_game()
        
        if player_id < 0 or player_id >= len(self.players):
            raise ValueError("Invalid player")
        
        i, j = self.players[player_id]
        new_i, new_j = i + x, j + y

        if 0 <= new_i < self.height and 0 <= new_j < self.width \
            and self.grid[new_i][new_j] and [new_i, new_j] not in self.players:
            self.players[player_id] = [new_i, new_j] 
            return 1
        
        # when player is at corner room
        if (i, j) in [(0, 0), (4, 4), (0, 4), (4, 0)] \
            and [4 - i, 4 - j] not in self.players: 
            self.players[player_id] = [4 - i, 4 - j]
            return 1
        
        return 0
    
    def start_game(self):
        if not self.live:
            self.live = True
            self.answer['weapon'] = random.choice(list(range(6)))
            self.answer['room'] = random.choice(list(range(9)))
            self.answer['killer'] = random.choice(list(range(len(self.players))))
        else:
            print('Game already started.')

    def is_player_live(self, player_id: int) -> bool:
        return 0 <= player_id < len(self.players) and \
                self.players[player_id][0] != -1 and self.players[player_id][1] != -1
    
    def terminate_player(self, player_id: int) -> bool:
        if self.live and self.is_player_live(player_id):
            self.players[player_id] = [-1, -1]
            print(f'Player {player_id} is terminated successfully.')
            return True
        
        print(f'Player {player_id} can not be terminated')
        return False

    def __get_room_coord(self, room_id: int):
        # with valid room_id
        return [room_id // 3 * 2, room_id % 3]

    def is_suggestion_valid(self, player_id: int, suspect: int, room_id: int, weapon_id: int):
        return self.is_player_live(player_id) and self.is_player_live(suspect) \
            and 0 <= room_id < 9 and 0 <= weapon_id < 6 \
            and self.__get_room_coord(room_id) == self.players[player_id]
    
    def is_accusation_valid(self, player_id: int, suspect: int, room_id: int, weapon_id: int):
        return self.is_player_live(player_id) and self.is_player_live(suspect) \
            and 0 <= room_id < 9 and 0 <= weapon_id < 6 

    def _check_answer(self, suspect: int, room: int, weapon: int) -> bool:
        return self.answer.get('killer', -1) == suspect and \
               self.answer.get('room', -1) == room and \
               self.answer.get('weapon', -1) == weapon

    def suggest(self, player_id, suspect, room_id, weapon_id):
        if self.is_suggestion_valid(player_id, suspect, room_id, weapon_id):
            self.players[suspect] = self.__get_room_coord(room_id)
            if self._check_answer(suspect, room_id, weapon_id):
                return True    
        else:
            print('Suggestion is not valid')
        
        return False

    def accuse(self, player_id: int, suspect: int, room: int, weapon: int) -> bool:
        if self.is_accusation_valid(player_id, suspect, room, weapon) and \
            self._check_answer(suspect, room, weapon):
            print(f'Accusation is correct, {player_id} wins the game')
            self.live = False
            self.winner = player_id
            for i in range(len(self.players)):
                self.terminate_player(i)
            return True
        
        self.terminate_player(player_id)
        return False
        

# initialize global grid
grid = GameGrid()


@app.route('/game_console')
def game_board():
    return "Welcome to the game console!"


@socketio.on('setup_board')
def initialize_board(data):
    id = grid.add_player()
    msg = f'set up player to {id}'
    print(msg)
    socketio.emit('setup_info', {'id': id, 'game_status': grid.game_status})


@socketio.on('update_grid')
def handle_update_grid(data):
    print('update grid with data ', data, grid.game_status)
    player = data['player']
    x = data['x']
    y = data['y']
    mv = grid.move_player(player, x, y)
    send('move player {} by ({}, {}) is {}valid'.format(player, x, y, '' if mv else 'in'), broadcast=True)
    send(f'player at {grid.players[player]}')
    socketio.emit('move', {'game_status': grid.game_status})

@socketio.on('make_suggestion')
def handle_make_suggestion(data):
    player = data['player']
    suspect = data['suspect']
    room = data['room']
    weapon = data['weapon']
    outcome = grid.suggest(player, suspect, room, weapon)
    socketio.emit('suggest', {'outcome': outcome, 'game_status': grid.game_status})

@socketio.on('make_accusation')
def handle_make_accusation(data):
    player = data['player']
    suspect = data['suspect']
    room = data['room']
    weapon = data['weapon']
    outcome = grid.accuse(player, suspect, room, weapon)
    socketio.emit('accusation', {'outcome': outcome, 'game_status': grid.game_status})


if __name__ == '__main__':
    app.debug = True 
    socketio.run(app, port=5000, debug=True)